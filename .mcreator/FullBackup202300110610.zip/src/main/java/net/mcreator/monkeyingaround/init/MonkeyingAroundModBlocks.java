
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.monkeyingaround.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.monkeyingaround.block.RainforestplanksBlock;
import net.mcreator.monkeyingaround.block.RainforestlogBlock;
import net.mcreator.monkeyingaround.block.RainforestLeavesBlock;
import net.mcreator.monkeyingaround.block.BananaStemBlock;
import net.mcreator.monkeyingaround.block.BananaStem2Block;
import net.mcreator.monkeyingaround.block.BananaStem1Block;
import net.mcreator.monkeyingaround.MonkeyingAroundMod;

public class MonkeyingAroundModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MonkeyingAroundMod.MODID);
	public static final RegistryObject<Block> RAINFORESTPLANKS = REGISTRY.register("rainforestplanks", () -> new RainforestplanksBlock());
	public static final RegistryObject<Block> RAINFORESTLOG = REGISTRY.register("rainforestlog", () -> new RainforestlogBlock());
	public static final RegistryObject<Block> RAINFOREST_LEAVES = REGISTRY.register("rainforest_leaves", () -> new RainforestLeavesBlock());
	public static final RegistryObject<Block> BANANA_STEM = REGISTRY.register("banana_stem", () -> new BananaStemBlock());
	public static final RegistryObject<Block> BANANA_STEM_1 = REGISTRY.register("banana_stem_1", () -> new BananaStem1Block());
	public static final RegistryObject<Block> BANANA_STEM_2 = REGISTRY.register("banana_stem_2", () -> new BananaStem2Block());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			RainforestLeavesBlock.blockColorLoad(event);
		}

		@SubscribeEvent
		public static void itemColorLoad(RegisterColorHandlersEvent.Item event) {
			RainforestLeavesBlock.itemColorLoad(event);
		}
	}
}
