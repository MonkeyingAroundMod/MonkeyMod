
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.monkeyingaround.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.monkeyingaround.item.MonkeyKeyItem;
import net.mcreator.monkeyingaround.item.BananaItem;
import net.mcreator.monkeyingaround.MonkeyingAroundMod;

public class MonkeyingAroundModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MonkeyingAroundMod.MODID);
	public static final RegistryObject<Item> RAINFORESTPLANKS = block(MonkeyingAroundModBlocks.RAINFORESTPLANKS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> RAINFORESTLOG = block(MonkeyingAroundModBlocks.RAINFORESTLOG, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> RAINFOREST_LEAVES = block(MonkeyingAroundModBlocks.RAINFOREST_LEAVES, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> BANANA = REGISTRY.register("banana", () -> new BananaItem());
	public static final RegistryObject<Item> MONKEY_KEY = REGISTRY.register("monkey_key", () -> new MonkeyKeyItem());
	public static final RegistryObject<Item> BANANA_STEM = block(MonkeyingAroundModBlocks.BANANA_STEM, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> BANANA_STEM_1 = block(MonkeyingAroundModBlocks.BANANA_STEM_1, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> BANANA_STEM_2 = block(MonkeyingAroundModBlocks.BANANA_STEM_2, CreativeModeTab.TAB_BUILDING_BLOCKS);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
